package logic;

import model.Order;
import model.Site;
import model.StatusOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Manager {
    public static List<Order> orderList = new ArrayList<>();
    public static List<Site> siteList = new ArrayList<>();

    static {
        orderList.add(new Order("1", "Item1", 10, "2024-05-15", StatusOrder.CHECK_SITE, ""));
        orderList.add(new Order("2", "Item2", 40, "2024-05-16", StatusOrder.CHECK_SITE, ""));
        orderList.add(new Order("3", "Item3", 30, "2024-05-17", StatusOrder.CANCEL, "Hết hàng"));
        orderList.add(new Order("4", "Item2", 20, "2024-05-17", StatusOrder.DONE, "", "Site3"));
        orderList.add(new Order("5", "Item1", 40, "2024-05-17", StatusOrder.CANCEL, "Hết hàng"));
        orderList.add(new Order("6", "Item2", 10, "2024-05-17", StatusOrder.CHECK_REPO, "","Site3"));
        orderList.add(new Order("7", "Item3", 30, "2024-05-17", StatusOrder.CHECK_REPO, "","Site1"));
        orderList.add(new Order("8", "Item2", 5, "2024-05-17", StatusOrder.CHECK_REPO, "","Site4"));
        orderList.add(new Order("9", "Item2", 5, "2024-05-17", StatusOrder.CANCEL_SITE, "","Site hủy đơn của bạn"));
        orderList.add(new Order("10", "Item2", 50, "2024-05-17", StatusOrder.CANCEL_SITE, "","Site hủy đơn của bạn"));
        // Tạo danh sách site
        siteList.add(new Site("Site1", "Item1", "cái", "đường biển", 20));
        siteList.add(new Site("Site2", "Item1", "cái", "đường biển", 10));
        siteList.add(new Site("Site3", "Item2", "cái", "đường biển", 15));
        siteList.add(new Site("Site4", "Item2", "cái", "đường biển", 30));
        siteList.add(new Site("Site5", "Item3", "cái", "đường biển", 5));
        siteList.add(new Site("Site6", "Item3", "cái", "đường biển", 20));
    }

    public static Order findOrderById(String id){
        for (Order o:orderList) {
            if (o.getOrderId().equals(id)){
                return o;
            }
        }
        return null;
    }

    public static Site findSiteById(String id){
        for (Site s:siteList) {
            if (s.getSiteCode().equals(id)){
                return s;
            }
        }
        return null;
    }

    public static void splitOrders(String idOrder, int quantity1, int quantity2){
        Order order = findOrderById(idOrder);
        if (order != null){
            orderList.remove(order);
            orderList.add(new Order(UUID.randomUUID().toString(), order.getMerchandiseCode(), quantity1, order.getDeliveryDate(), StatusOrder.CHECK_SITE, order.getReasonCancel()));
            orderList.add(new Order(UUID.randomUUID().toString(), order.getMerchandiseCode(), quantity2, order.getDeliveryDate(), StatusOrder.CHECK_SITE, order.getReasonCancel()));
        }
    }

    public static void addOrder(Order order) {
        orderList.add(order);
    }
}
