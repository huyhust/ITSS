package model;

public class Order {
    private String orderId;
    private String merchandiseCode;
    private int quantity;
    private String deliveryDate;
    private StatusOrder status;
    private String reasonCancel;
    private String siteCode;

    public Order(String orderId, String merchandiseCode, int quantity, String deliveryDate, StatusOrder status, String reasonCancel) {
        this.orderId = orderId;
        this.merchandiseCode = merchandiseCode;
        this.quantity = quantity;
        this.deliveryDate = deliveryDate;
        this.status = status;
        this.reasonCancel = reasonCancel;
    }
    public Order(String orderId, String merchandiseCode, int quantity, String deliveryDate, StatusOrder status, String reasonCancel,String siteCode ) {
        this.orderId = orderId;
        this.merchandiseCode = merchandiseCode;
        this.quantity = quantity;
        this.deliveryDate = deliveryDate;
        this.status = status;
        this.reasonCancel = reasonCancel;
        this.siteCode = siteCode;
    }

    public String getSiteCode() {
        return siteCode;
    }

    public void setSiteCode(String siteCode) {
        this.siteCode = siteCode;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getMerchandiseCode() {
        return merchandiseCode;
    }

    public void setMerchandiseCode(String merchandiseCode) {
        this.merchandiseCode = merchandiseCode;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public StatusOrder getStatus() {
        return status;
    }

    public void setStatus(StatusOrder status) {
        this.status = status;
    }

    public String getReasonCancel() {
        return reasonCancel;
    }

    public void setReasonCancel(String reasonCancel) {
        this.reasonCancel = reasonCancel;
    }
}
