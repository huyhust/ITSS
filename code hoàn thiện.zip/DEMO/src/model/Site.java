package model;

public class Site {
    private String siteCode;
    private String merchandiseCode;
    private String unit;
    private String deliveryMeans;
    private int inStockQuantity;

    public Site(String siteCode, String merchandiseCode, String unit, String deliveryMeans, int inStockQuantity) {
        this.siteCode = siteCode;
        this.merchandiseCode = merchandiseCode;
        this.unit = unit;
        this.deliveryMeans = deliveryMeans;
        this.inStockQuantity = inStockQuantity;
    }

    public String getSiteCode() {
        return siteCode;
    }

    public void setSiteCode(String siteCode) {
        this.siteCode = siteCode;
    }

    public String getMerchandiseCode() {
        return merchandiseCode;
    }

    public void setMerchandiseCode(String merchandiseCode) {
        this.merchandiseCode = merchandiseCode;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getDeliveryMeans() {
        return deliveryMeans;
    }

    public void setDeliveryMeans(String deliveryMeans) {
        this.deliveryMeans = deliveryMeans;
    }

    public int getInStockQuantity() {
        return inStockQuantity;
    }

    public void setInStockQuantity(int inStockQuantity) {
        this.inStockQuantity = inStockQuantity;
    }
}
