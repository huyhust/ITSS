package model;

public enum StatusOrder {
    CHECK_SITE, CANCEL, CANCEL_SITE, NEW, CHECK_REPO, DONE;
}
