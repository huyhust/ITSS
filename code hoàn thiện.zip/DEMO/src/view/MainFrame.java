package view;

import model.Order;
import model.Site;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class MainFrame extends JFrame {
    private JButton btnOrder, btnAddSite, btnCheckRepo, btnSite;

    public MainFrame(List<Order> orders, List<Site> sites) {
        setTitle("Main Menu");
        setSize(400, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(2, 1));

        btnOrder = new JButton("Xử lý đơn đặt hàng");
        btnSite = new JButton("Danh sách các Site");
        btnAddSite = new JButton("Xử lý đơn hàng cần đặt của bộ phận quốc tế. ");
        btnCheckRepo = new JButton("Xử lý đơn hàng nhập kho. ");
//        btnOrder = new JButton("Xử lý đơn hàng nhập kho. ");

        btnOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xu_ly_don_dat_hang orderFrame = new xu_ly_don_dat_hang(orders);
                orderFrame.setVisible(true);
            }
        });
        btnSite.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SiteFrame siteFrame = new SiteFrame(sites, orders);
                siteFrame.setVisible(true);
            }
        });

        btnAddSite.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xu_ly_don_dat_hang_bo_phan_qt obj = new xu_ly_don_dat_hang_bo_phan_qt(orders, sites);
                obj.setVisible(true);
            }
        });
        btnCheckRepo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xu_ly_don_hang_nhap_kho obj = new xu_ly_don_hang_nhap_kho(orders);
                obj.setVisible(true);
            }
        });

        panel.add(btnOrder);
        panel.add(btnSite);
        panel.add(btnAddSite);
        panel.add(btnCheckRepo);

        add(panel);
    }
}
