package view;

import logic.Manager;
import model.Order;
import model.Site;
import model.StatusOrder;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.UUID;

public class SiteFrame extends JFrame {
    private JTable tableSites;
    private DefaultTableModel sitesModel;
    private JScrollPane scrollPaneOrders;
    private JButton btnCreate;


    public SiteFrame(List<Site> sites, List<Order> orderList) {
        setTitle("Orders");
        setSize(800, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelButtons = new JPanel(new FlowLayout());
        btnCreate = new JButton("Create Order");


        panelButtons.add(btnCreate);


        JPanel panel = new JPanel(new BorderLayout());

        // Table for sites dow
        sitesModel = new DefaultTableModel();
        sitesModel.addColumn("Site Code");
        sitesModel.addColumn("Merchandise Code");
        sitesModel.addColumn("Unit");
        sitesModel.addColumn("Delivery Means");
        sitesModel.addColumn("In-stock Quantity");

        tableSites = new JTable(sitesModel);
        scrollPaneOrders = new JScrollPane(tableSites);

        // Action Listeners
        btnCreate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Order order = showOrderDialog(null);
                if (order != null) {
                    Manager.addOrder(order);
                    JOptionPane.showMessageDialog(null, "Thêm Đơn Thành Công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                    xu_ly_don_dat_hang obj = new xu_ly_don_dat_hang(orderList);
                    obj.setVisible(true);
                }
            }
        });


        for (Site site : sites) {
            Object[] rowData = {site.getSiteCode(), site.getMerchandiseCode(), site.getUnit(), site.getDeliveryMeans(), site.getInStockQuantity()};
            sitesModel.addRow(rowData);
        }

        panel.add(panelButtons, BorderLayout.NORTH);
        panel.add(scrollPaneOrders, BorderLayout.CENTER);

        add(panel);
    }

    private Order showOrderDialog(Order order) {
        JTextField txtMerchandiseCode = new JTextField();
        JTextField txtQuantity = new JTextField();
        JTextField txtDeliveryDate = new JTextField();

        if (order != null) {
            txtMerchandiseCode.setText(order.getMerchandiseCode());
            txtQuantity.setText(String.valueOf(order.getQuantity()));
            txtDeliveryDate.setText(order.getDeliveryDate());
        }

        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(new JLabel("Merchandise Code:"));
        panel.add(txtMerchandiseCode);
        panel.add(new JLabel("Quantity:"));
        panel.add(txtQuantity);
        panel.add(new JLabel("Delivery Date:"));
        panel.add(txtDeliveryDate);

        int result = JOptionPane.showConfirmDialog(null, panel, "Order Details", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            String merchandiseCode = txtMerchandiseCode.getText();
            int quantity = Integer.parseInt(txtQuantity.getText());
            String deliveryDate = txtDeliveryDate.getText();

            if (order == null) {
                return new Order(UUID.randomUUID().toString(), merchandiseCode, quantity, deliveryDate, StatusOrder.NEW, "");
            } else {
                order.setMerchandiseCode(merchandiseCode);
                order.setQuantity(quantity);
                order.setDeliveryDate(deliveryDate);
                return order;
            }
        } else {
            return null;
        }
    }
}
