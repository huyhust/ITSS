package view;

import logic.Manager;
import model.Order;

import model.Site;
import model.StatusOrder;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class xu_ly_don_dat_hang extends JFrame {
    private JTable tableOrders;
    private DefaultTableModel ordersModel;
    private JScrollPane scrollPaneOrders;
    private JButton btnDoneOrder, btnCancelOrder, btnALLOrder, btnCheckRepoOrder, btnAddSiteOrder;
    private boolean isShowCancel;

    public xu_ly_don_dat_hang(List<Order> orderList) {
        setTitle("view.xu_ly_don_dat_hang");
        setSize(800, 500);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        // Table for orders
        ordersModel = new DefaultTableModel();
        ordersModel.addColumn("Order ID");
        ordersModel.addColumn("Merchandise Code");
        ordersModel.addColumn("Quantity");
        ordersModel.addColumn("Delivery Date");
        ordersModel.addColumn("IdSite");

        tableOrders = new JTable(ordersModel);
        scrollPaneOrders = new JScrollPane(tableOrders);

        loadOrderTable(orderList, null);


        // Panel for buttons
        JPanel panelButtons = new JPanel(new FlowLayout());
        btnDoneOrder = new JButton("Thành công");
        btnCancelOrder = new JButton("Đơn bi hủy");
        btnALLOrder = new JButton("Tất cả");
//        btnALLOrder = new JButton("Đơn vừa tạo");
        btnCheckRepoOrder = new JButton("Đơn cần xác nhận từ kho");
        btnAddSiteOrder = new JButton("Đơn cần thêm site");


        btnDoneOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadOrderTable(orderList, StatusOrder.DONE);
                isShowCancel = false;
            }
        });

        btnAddSiteOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadOrderTable(orderList, StatusOrder.CHECK_SITE);
                isShowCancel = false;
            }
        });

        btnCancelOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadOrderTable(orderList, StatusOrder.CANCEL);
                isShowCancel = true;
            }
        });
        btnALLOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadOrderTable(orderList, null);
                isShowCancel = false;
            }
        });
        btnCheckRepoOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadOrderTable(orderList, StatusOrder.CHECK_REPO);
                isShowCancel = false;

            }
        });

        tableOrders.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (isShowCancel) {
                    if (!e.getValueIsAdjusting()) {
                        int selectedRow = tableOrders.getSelectedRow();
                        if (selectedRow != -1) {
                            String idOrder = (String) ordersModel.getValueAt(selectedRow, 0);
                            Order order = Manager.findOrderById(idOrder);
                            JOptionPane.showMessageDialog(null, "Lý do hủy đơn : " + order.getReasonCancel(), "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                }

            }
        });

        panelButtons.add(btnALLOrder);
        panelButtons.add(btnDoneOrder);
        panelButtons.add(btnAddSiteOrder);
        panelButtons.add(btnCheckRepoOrder);
        panelButtons.add(btnCancelOrder);

        // Add components to main panel
        panel.add(scrollPaneOrders, BorderLayout.CENTER);
        panel.add(panelButtons, BorderLayout.NORTH);
        add(panel);
    }

    private void loadOrderTable(List<Order> orderList, StatusOrder statusOrder) {
        SwingUtilities.invokeLater(() -> {
            ordersModel.setRowCount(0);
            Color color = Color.BLACK;
            if (statusOrder == null) {
                for (Order order : orderList) {
                    Object[] rowData = {
                            order.getOrderId(),
                            order.getMerchandiseCode(),
                            order.getQuantity(),
                            order.getDeliveryDate(),
                            order.getSiteCode()
                    };
                    ordersModel.addRow(rowData);
                    tableOrders.setDefaultRenderer(Object.class, new CustomCellRenderer(color));
                }
                return;
            }
            if (statusOrder.equals(StatusOrder.CHECK_REPO)) {
                color = Color.ORANGE;
            } else if (statusOrder.equals(StatusOrder.CANCEL)) {
                color = Color.RED;
                for (Order order : orderList) {
                    if (order.getStatus().equals(StatusOrder.CANCEL) ||order.getStatus().equals(StatusOrder.CANCEL_SITE)) {
                        Object[] rowData = {
                                order.getOrderId(),
                                order.getMerchandiseCode(),
                                order.getQuantity(),
                                order.getDeliveryDate(),
                                order.getSiteCode()
                        };
                        ordersModel.addRow(rowData);
                        tableOrders.setDefaultRenderer(Object.class, new CustomCellRenderer(color));

                    }
                }
                return;
            }else if (statusOrder.equals(StatusOrder.DONE)) {
                color = Color.BLUE;
            }else if (statusOrder.equals(StatusOrder.CHECK_SITE)) {
                color = Color.MAGENTA;
            }
            for (Order order : orderList) {
                if (order.getStatus().equals(statusOrder)) {
                    Object[] rowData = {
                            order.getOrderId(),
                            order.getMerchandiseCode(),
                            order.getQuantity(),
                            order.getDeliveryDate(),
                            order.getSiteCode()
                    };
                    ordersModel.addRow(rowData);
                    tableOrders.setDefaultRenderer(Object.class, new CustomCellRenderer(color));

                }
            }
        });
    }


}

