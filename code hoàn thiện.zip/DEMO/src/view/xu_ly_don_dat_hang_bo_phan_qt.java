package view;

import logic.Manager;
import model.Order;
import model.Site;
import model.StatusOrder;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class xu_ly_don_dat_hang_bo_phan_qt extends JFrame {
    private JTable tableOrders, tableSites, tableSitesDow;
    private DefaultTableModel ordersModel, sitesModelUp, sitesModelDow;
    private JScrollPane scrollPaneOrders, scrollPaneSites, scrollPaneSitesDow;
    private JButton btnSaveSite, btnCancelOrder, btnSplitOrders;

    public xu_ly_don_dat_hang_bo_phan_qt(List<Order> orderList, List<Site> siteList) {
        setTitle("Inventory");
        setSize(1300, 500);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        // Table for orders
        ordersModel = new DefaultTableModel();
        ordersModel.addColumn("Order ID");
        ordersModel.addColumn("Merchandise Code");
        ordersModel.addColumn("Quantity");
        ordersModel.addColumn("Delivery Date");
        ordersModel.addColumn("IdSite");

        tableOrders = new JTable(ordersModel);
        scrollPaneOrders = new JScrollPane(tableOrders);

        loadOrderTable(orderList);

        // Table for sites
        sitesModelDow = new DefaultTableModel();
        sitesModelDow.addColumn("Site Code");
        sitesModelDow.addColumn("Merchandise Code");
        sitesModelDow.addColumn("Unit");
        sitesModelDow.addColumn("Delivery Means");
        sitesModelDow.addColumn("In-stock Quantity");

        tableSitesDow = new JTable(sitesModelDow);
        scrollPaneSitesDow = new JScrollPane(tableSitesDow);

        // Table for sites dow
        sitesModelUp = new DefaultTableModel();
        sitesModelUp.addColumn("Site Code");
        sitesModelUp.addColumn("Merchandise Code");
        sitesModelUp.addColumn("Unit");
        sitesModelUp.addColumn("Delivery Means");
        sitesModelUp.addColumn("In-stock Quantity");

        tableSites = new JTable(sitesModelUp);
        scrollPaneSites = new JScrollPane(tableSites);

        // Add selection listener for orders table
        tableOrders.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = tableOrders.getSelectedRow();
                    if (selectedRow != -1) {
                        String merchandiseCode = (String) ordersModel.getValueAt(selectedRow, 1);
                        int orderQuantity = getOrderQuantity(selectedRow); // Lấy số lượng đơn hàng

                        // Clear previous data
                        sitesModelUp.setRowCount(0);
                        sitesModelDow.setRowCount(0);

                        // Load sites for selected merchandise code
                        for (Site site : siteList) {
                            if (site.getMerchandiseCode().equals(merchandiseCode) && site.getInStockQuantity() >= orderQuantity) {
                                // Set color to red if site does not have enough stock
                                Color color = Color.GREEN;
                                sitesModelUp.addRow(new Object[]{site.getSiteCode(), site.getMerchandiseCode(), site.getUnit(), site.getDeliveryMeans(), site.getInStockQuantity()});
                                tableSites.setDefaultRenderer(Object.class, new CustomCellRenderer(color)); // Apply renderer for entire row
                            }
                        }

                        for (Site site : siteList) {
                            if (site.getMerchandiseCode().equals(merchandiseCode) && site.getInStockQuantity() < orderQuantity) {
                                // Set color to red if site does not have enough stock
                                Color color = Color.RED;
                                sitesModelDow.addRow(new Object[]{site.getSiteCode(), site.getMerchandiseCode(), site.getUnit(), site.getDeliveryMeans(), site.getInStockQuantity()});
                                tableSitesDow.setDefaultRenderer(Object.class, new CustomCellRenderer(color)); // Apply renderer for entire row
                            }
                        }
                    }
                }
            }
        });

        // Panel for buttons
        JPanel panelButtons = new JPanel(new FlowLayout());
        btnSaveSite = new JButton("Save Site");
        btnCancelOrder = new JButton("Cancel Order");
        btnSplitOrders = new JButton("Split Order");

        btnSaveSite.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedOder = tableOrders.getSelectedRow();
                int selectedSite = tableSites.getSelectedRow();

                if (selectedOder != -1 && selectedSite != -1) {
                    String orderId = (String) ordersModel.getValueAt(selectedOder, 0);
                    String idSite = (String) sitesModelUp.getValueAt(selectedSite, 0);
                    Order order = Manager.findOrderById(orderId);
                    if (order != null) order.setSiteCode(idSite);
                    loadOrderTable(orderList);
                }
            }
        });

        btnCancelOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedOder = tableOrders.getSelectedRow();
                if (selectedOder != -1) {
                    int confirm = JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn muốn hủy đơn hàng này?", "Xác nhận", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        String orderId = (String) ordersModel.getValueAt(selectedOder, 0);
                        Order order = Manager.findOrderById(orderId);
                        if (order != null) {
                            order.setStatus(StatusOrder.CANCEL);
                            order.setReasonCancel("Không có site nào");
                        }
                        loadOrderTable(orderList);
                        JOptionPane.showMessageDialog(null, "Hủy hàng thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Bạn chưa chọn đơn hàng nào!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        btnSplitOrders.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedOder = tableOrders.getSelectedRow();
                if (selectedOder != -1) {
                    String orderId = (String) ordersModel.getValueAt(selectedOder, 0);

                    JTextField quantity1Field = new JTextField(5);
                    JTextField quantity2Field = new JTextField(5);

                    JPanel panel = new JPanel(new GridLayout(2, 2));
                    panel.add(new JLabel("Quantity 1:"));
                    panel.add(quantity1Field);
                    panel.add(new JLabel("Quantity 2:"));
                    panel.add(quantity2Field);

                    int confirm = JOptionPane.showConfirmDialog(null, panel, "Nhập số lượng chia 2 đơn", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                    if (confirm == JOptionPane.OK_OPTION) {
                        int quantity1 = Integer.parseInt(quantity1Field.getText());
                        int quantity2 = Integer.parseInt(quantity2Field.getText());
                        Order order = Manager.findOrderById(orderId);
                        if (order != null) {
                            if (order.getQuantity() != (quantity1 + quantity2)) {
                                JOptionPane.showMessageDialog(null, "Bạn nhập số lượng sai rồi!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                                return;
                            }
                        }
                        Manager.splitOrders(orderId, quantity1, quantity2);
                        loadOrderTable(orderList);
                    } else {
                        System.out.println("User canceled the input.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Bạn chưa chọn đơn hàng nào!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        panelButtons.add(btnSaveSite);
        panelButtons.add(btnCancelOrder);
        panelButtons.add(btnSplitOrders);

        // Add components to main panel
        panel.add(scrollPaneOrders, BorderLayout.CENTER);
        panel.add(panelButtons, BorderLayout.NORTH);
        panel.add(scrollPaneSites,BorderLayout.LINE_START);
        panel.add(scrollPaneSitesDow,BorderLayout.LINE_END);
//        panel.add(scrollPaneSites, BorderLayout.SOUTH);
//        panel.add(scrollPaneSitesDow, BorderLayout.SOUTH);

        add(panel);
    }

    // Method to get the quantity of the selected order
    private int getOrderQuantity(int selectedRow) {
        return (int) ordersModel.getValueAt(selectedRow, 2);
    }

    private void loadOrderTable(List<Order> orderList) {
        SwingUtilities.invokeLater(() -> {
            ordersModel.setRowCount(0);
            for (Order order : orderList) {
                if (order.getStatus().equals(StatusOrder.CHECK_SITE) || order.getStatus().equals(StatusOrder.CANCEL_SITE)) {
                    Object[] rowData = {
                            order.getOrderId(),
                            order.getMerchandiseCode(),
                            order.getQuantity(),
                            order.getDeliveryDate(),
                            order.getSiteCode()
                    };
                    ordersModel.addRow(rowData);
                }
            }
        });
    }


}
