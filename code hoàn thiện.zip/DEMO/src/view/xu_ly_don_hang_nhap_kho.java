package view;

import logic.Manager;
import model.Order;

import model.StatusOrder;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class xu_ly_don_hang_nhap_kho extends JFrame {
    private JTable tableOrders;
    private DefaultTableModel ordersModel;
    private JScrollPane scrollPaneOrders;
    private JButton btnDoneOrder, btnCancelOrder;

    public xu_ly_don_hang_nhap_kho(List<Order> orderList) {
        setTitle("view.xu_ly_don_hang_nhap_kho");
        setSize(800, 500);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        // Table for orders
        ordersModel = new DefaultTableModel();
        ordersModel.addColumn("Order ID");
        ordersModel.addColumn("Merchandise Code");
        ordersModel.addColumn("Quantity");
        ordersModel.addColumn("Delivery Date");
        ordersModel.addColumn("IdSite");

        tableOrders = new JTable(ordersModel);
        scrollPaneOrders = new JScrollPane(tableOrders);

        loadOrderTable(orderList);


        // Panel for buttons
        JPanel panelButtons = new JPanel(new FlowLayout());
        btnDoneOrder = new JButton("Done Order");
        btnCancelOrder = new JButton("Cancel Order");

        btnDoneOrder.addActionListener(new ActionListener() {
            @Override

            public void actionPerformed(ActionEvent e) {
                int selectedOder = tableOrders.getSelectedRow();
                if (selectedOder != -1) {
                    String orderId = (String) ordersModel.getValueAt(selectedOder, 0);
                    JTextField quantity = new JTextField(5);

                    JPanel panel = new JPanel(new GridLayout(2, 2));
                    panel.add(new JLabel("Nhập số lượng sản phẩm kho được nhận:"));
                    panel.add(quantity);


                    int confirm = JOptionPane.showConfirmDialog(null, panel, "Nhập số lượng sản phẩm kho được nhận :  ", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                    if (confirm == JOptionPane.OK_OPTION) {
                        int quantity1 = Integer.parseInt(quantity.getText());
                        Order order = Manager.findOrderById(orderId);
                        if (order != null) {
                            if (order.getQuantity() == quantity1) {
                                order.setStatus(StatusOrder.DONE);
                                loadOrderTable(orderList);
                            } else {
                                JOptionPane.showMessageDialog(null, "Số lượng kho nhận khác với số lượng đơn, cần kiểm tra lại!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                            }
                        }
                        loadOrderTable(orderList);
                    } else {
                        System.out.println("User canceled the input.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Bạn chưa chọn đơn hàng nào!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        btnCancelOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedOder = tableOrders.getSelectedRow();
                if (selectedOder != -1) {
                    int confirm = JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn muốn hủy đơn hàng này với lý do: Không đủ số lượng?", "Xác nhận", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        String orderId = (String) ordersModel.getValueAt(selectedOder, 0);
                        Order order = Manager.findOrderById(orderId);
                        if (order != null) {
                            order.setStatus(StatusOrder.CANCEL);
                            order.setReasonCancel("Không đủ số lươợng");
                        }
                        loadOrderTable(orderList);
                        JOptionPane.showMessageDialog(null, "Hủy hàng thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Bạn chưa chọn đơn hàng nào!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });


        panelButtons.add(btnDoneOrder);
        panelButtons.add(btnCancelOrder);

        // Add components to main panel
        panel.add(scrollPaneOrders, BorderLayout.CENTER);
        panel.add(panelButtons, BorderLayout.NORTH);
        add(panel);
    }

    private void loadOrderTable(List<Order> orderList) {
        SwingUtilities.invokeLater(() -> {
            ordersModel.setRowCount(0);
            for (Order order : orderList) {
                if (order.getStatus().equals(StatusOrder.CHECK_REPO)) {
                    Object[] rowData = {
                            order.getOrderId(),
                            order.getMerchandiseCode(),
                            order.getQuantity(),
                            order.getDeliveryDate(),
                            order.getSiteCode()
                    };
                    ordersModel.addRow(rowData);
                }
            }
        });
    }


}

